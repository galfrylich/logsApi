package testApi;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Date;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.BasicConfigurator;

@WebServlet("/getLogs")
public class getLogs extends HttpServlet{
	private static final SecureRandom secureRandom = new SecureRandom(); 
	private static final Base64.Encoder base64Encoder = Base64.getUrlEncoder(); 
	private String auth = "Bearer" +" " + generateNewToken();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		try {
			String authTokenHeader = req.getHeader("Authorization");
			if(authTokenHeader == auth) {
				File myLogs = new File("./logs.txt");
			      Scanner Read = new Scanner(myLogs);
			      while (Read.hasNextLine()) {
			        String data = Read.nextLine();
			        resp.getOutputStream().println(data);
			      }
			      Read.close();
			}else {
				resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		      
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		
	}
	
	public static String generateNewToken() {
	    byte[] randomBytes = new byte[24];
	    secureRandom.nextBytes(randomBytes);
	    return base64Encoder.encodeToString(randomBytes);
	}
}
