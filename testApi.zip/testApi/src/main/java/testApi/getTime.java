package testApi;

import java.io.IOException;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.BasicConfigurator;




@WebServlet("/getTime")
public class getTime extends HttpServlet{

	private static final Logger LOG = Logger.getLogger(getTime.class.getName());

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.setProperty("java.util.logging.SimpleFormatter.format", "%4$s: %5$s%n");
		BasicConfigurator.configure();
		Date today = new Date();
		String now = today.toString();
		writeLog("Time requested at "+ now);
		resp.getOutputStream().println(now);

	}

	public void writeLog(String log) {

		FileHandler fh;  
		try {  
			fh = new FileHandler("./logs.txt",true);  
			LOG.addHandler(fh);
			SimpleFormatter formatter = new SimpleFormatter();  
			fh.setFormatter(formatter);
			LOG.log(Level.INFO,log);


		} catch (SecurityException e) {  
			e.printStackTrace();  
		} catch (IOException e) {  
			e.printStackTrace();  
		} 
	}



}




